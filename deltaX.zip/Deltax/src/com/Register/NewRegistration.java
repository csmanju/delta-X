package com.Register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class NewRegistration {

	
	@Test
	public void NewRegistration() throws Exception
		// TODO Auto-generated method stub

	{
		System.setProperty("webdriver.gecko.driver","./Drivers/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("http://adjiva.com/qa-test/");
		
		//Enter First name
		driver.findElement(By.name("first_name")).sendKeys("Manjunath");
		
		//name
		driver.findElement(By.name("last_name")).sendKeys("channi");
		
		//Selecting city in a Multiple SELECT elements
    		Select Dept  = new Select(driver.findElement(By.xpath("//html//body//div//form//fieldset//div[3]//div//div//select")));
    		Dept.selectByVisibleText("Engineering");
  
    		//Username
    		driver.findElement(By.name("user_name")).sendKeys("Manjunathchanni");
    		
    		//password
    		driver.findElement(By.name("user_password")).sendKeys("qwertyui");
    		
    		//confirm password
    		driver.findElement(By.name("confirm_password")).sendKeys("qwertyui");
    		
    		//email
    		driver.findElement(By.name("email")).sendKeys("manjuchanni@gmail.com");
    		
    		//phone number
    		driver.findElement(By.name("contact_no")).sendKeys("1234567891");
    		
    		//submit button
    		driver.findElement(By.xpath("//html//body//div//form//fieldset//div[10]//div//button")).click();
    		
    		Thread.sleep(5000);
    		driver.quit();
    			
    			
	}

		}


